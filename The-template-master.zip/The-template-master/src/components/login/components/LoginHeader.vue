<template>
  <div class="allcontent">
    <img src="../../../assets/img/logo.png" alt>
  </div>
</template>

<script>
export default {};
</script>

<style scoped>
.allcontent img {
  display: block;
  width: 1.8rem;
  height: 1.6rem;
  margin: 0 auto;
  margin-bottom: 1.28rem;
}
</style>


