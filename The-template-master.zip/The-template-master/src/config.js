export default {
  //接口基础地址
  api_base: process.env.NODE_ENV === 'development' ? '/' : 'http://xx.com'
}
