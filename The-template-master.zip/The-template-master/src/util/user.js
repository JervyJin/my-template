import store from '@/store'
import _ from 'lodash'

export function initUserInfo() {
  let token = _.toString(localStorage.getItem('token'))
  store.commit('setToken', token)
  let uid = _.toString(localStorage.getItem('uid'))
  let username = _.toString(localStorage.getItem('username'))
  let avatar = _.toString(localStorage.getItem('avatar'))
  store.commit('setUser', { uid, username, avatar })
}
