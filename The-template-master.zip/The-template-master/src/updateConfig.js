export default {
    update_url: "http://appup.baodekeji.com/api/update"
}